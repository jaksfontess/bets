from django.apps import AppConfig


class PartidasConfig(AppConfig):
    name = 'partidas'
