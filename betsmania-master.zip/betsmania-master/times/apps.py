from django.apps import AppConfig


class TimesConfig(AppConfig):
    name = 'times'
