from django.apps import AppConfig


class ApostasConfig(AppConfig):
    name = 'apostas'
