import os

SETTINGS_DIR = os.path.normpath(os.path.dirname(__file__))
APP_DIR = os.path.dirname(SETTINGS_DIR)
PROJECT_DIR = os.path.dirname(APP_DIR)
